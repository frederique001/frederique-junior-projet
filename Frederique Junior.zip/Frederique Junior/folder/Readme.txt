Nom          : Frederique
Prenom       : Jean Marais Junio
Niveau etude : 2e annee
Vacation     : SCiences Informatiques
code         : 33396